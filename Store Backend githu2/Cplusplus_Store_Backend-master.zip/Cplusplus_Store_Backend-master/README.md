# C-_Store_Backend
Implementation of the back end of a store in C++ utilizing dynamic memory allocation, polymorphism, and objects.
Please see "Store Backend Design.pdf" for detailed implementation notes.
