# Store-Backend
Backend program for organizing data for a store using product and customer classes. Usign a driver program, check for correctness.
