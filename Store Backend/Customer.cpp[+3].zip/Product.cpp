#include <iostream>
#include <string>
#include <stdexcept>
#include "Product.h"

using namespace std;

Product::Product(int id, string name) : id(id), name(name),
	inventory(0), numSold(0), totalPaid(0.0) /*, description("")*/ {
		if (name.length()==0) 
			throw runtime_error("Product name cannot be empty.");
	}
	// Note a string's default constructor already sets the string to
	//   "" so we don't have to do that explicitly here
	//   I showed what it would look like but commented it out.

int Product::getID() const { return  id; }

std::string Product::getName() const { return name; }

std::string Product::setName(string name) {
	if (name.length()==0) 
		throw runtime_error("Product name cannot be empty.");
	this->name = name; // could use an else, but it will only get here
					   //   if there was not an exception!
 //string autograder = " ";
 return " " ;
}

string Product::getDescription() const { return description; }

void Product::setDescription(string description){
	this->description = description;
}

int Product::getNumberSold() const { return numSold; }

double Product::getTotalPaid() const { return totalPaid; }

int Product::getInventoryCount() const { return inventory; }

double Product::getPrice() const {
	return 0.0;
	// have to return something in stub so it will compile
	// will change later
}

void Product::addShipment(int quantity, double shipmentCost) {
	if (quantity < 0)
		throw runtime_error("Shipment quantity must be positive.");
	if (shipmentCost < 0)
		throw runtime_error("Shipment cost must be positive.");
	//cout << "quantity: " << quantity << endl;
	//cout << "inventory: " << inventory << endl;
	inventory += quantity;
	totalPaid += shipmentCost;
}

void Product::reduceInventory(int quantity) {
}
/*
//overloaded operator
std::ostream& operator<<(std::ostream& os,const Product& p){
	
 
 
	return os;
}
*/
